$(document).ready(function () {

    
    /////////////////////////////////////////////////////////
    /////                                               /////
    ///// 1-Запуск счетчика цифр при скролле            /////   
    /////                                               /////
    /////////////////////////////////////////////////////////
    
    var show = true;
    var countbox = "#counts";
    $(window).on("scroll load resize", function () {
        if (!show) return false;                      // Отменяем показ анимации, если она уже была выполнена
        var w_top       = $(window).scrollTop()     ; // Количество пикселей на которое была прокручена страница
        var e_top       = $(countbox).offset()      ; // Расстояние от блока со счетчиками до верха всего документа
        var w_height    = $(window).height()        ; // Высота окна браузера
        var d_height    = $(document).height()      ; // Высота всего документа
        var e_height    = $(countbox).outerHeight() ; // Высота всего документа
        if (w_top + 500 >= e_top || w_height + w_top == d_height || e_height + e_top < w_height) {
            $(".benefits__number").spincrement();
            // $('.benefits__number').css('opacity', '1');
            // $('.benefits__number').spincrement({
            //     thousandSeparator: "",
            //     duration: 1200
            // });
            show = false;
        }
    });

    // 2) navigation scroll (menu > item-link > click)
    // плавное перемещение страницы к нужному блоку
    $("nav li a").click(function () {
        elementClick = $(this).attr("href");
        destination = $(elementClick).offset().top;
        $("body,html").animate({ scrollTop: destination }, 800); // время прокрутки по клику
    });

    // 3) fixed top navigation (scroll > page)
    //фиксируем шапку при скролле
    $(window).scroll(function () {
        if ($(this).scrollTop() > 300) {
            $('nav').addClass("fixed-nav");
        } else {
            $('nav').removeClass("fixed-nav");
        }
    });

    //4) mobile menu open (burger-menu > click)
    //and link navigation click - mobile menu d-none
    $('.btn-open, .menu a').click(function () {
        $('.menu-collapse').toggleClass('d-none').css('order', '1');
        $('.menu').toggleClass('menu-opened');
     
    });

    //5) burger animation click (focus-active)
    //появление стрелки
    $('.btn-open').on('click', function (e) {
        e.preventDefault;
        $(this).toggleClass('btn-open-active')
    });

    //6) burger animation click (focus-static)
    //скрываем стрелку
    $('.menu a').on('click', function (e) {
         e.preventDefault;
         $('.btn-open').removeClass('btn-open-active')
     });

});