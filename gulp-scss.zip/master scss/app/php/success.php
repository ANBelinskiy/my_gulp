<?php
header("Content-Type: text/html; charset=utf-8");
$tel = htmlspecialchars($_POST["tel"]);
$subject = htmlspecialchars($_POST["subject"]);

$refferer = getenv('HTTP_REFERER');
$date=date("d.m.y"); // число.месяц.год  
$time=date("H:i"); // часы:минуты:секунды 
$myemail = "panipack2018@gmail.com"; // e-mail администратора

// Отправка письма администратору сайта
$tema = "Заявка на обратный звонок";
$message_to_myemail = "Текст письма:
<br><br>
$subject<br>
Телефон: $tel<br>
Источник (ссылка): $refferer
";

mail($myemail, $tema, $message_to_myemail, "From: Pani Pack <panipack2018@gmail.com> \r\n Reply-To: Pani Pack \r\n"."MIME-Version: 1.0\r\n"."Content-type: text/html; charset=utf-8\r\n" );

// Сохранение инфо о лидах в файл leads.xls
$f = fopen("leads.xls", "a+");
fwrite($f," <tr>");    
fwrite($f," <td>$tel</td>   <td>$date / $time</td>");   
fwrite($f," <td>$refferer</td>");    
fwrite($f," </tr>");  
fwrite($f,"\n ");    
fclose($f);

?>